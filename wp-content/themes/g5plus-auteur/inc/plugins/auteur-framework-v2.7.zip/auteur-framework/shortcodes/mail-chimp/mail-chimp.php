<?php
/**
 * The template for displaying mailchimp.php
 *
 * @package WordPress
 * @subpackage auteur
 * @since auteur 1.0
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}
class WPBakeryShortCode_GSF_Mail_Chimp extends G5P_ShortCode_Base {
}
