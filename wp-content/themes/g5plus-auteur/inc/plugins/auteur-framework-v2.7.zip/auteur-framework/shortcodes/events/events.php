<?php
/**
 * The template for displaying events.php
 *
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}
class WPBakeryShortCode_GSF_Events extends G5P_ShortCode_Base {
}